
int myextern;

int main()
{

}

void goobie()
{

}
