#!/usr/bin/perl

print "Test1 directory tests\n";
system "cd Test1; run.pl";

print "Test2 directory tests\n";
system "cd Test2; run.pl";

print "Test3 directory tests\n";
system "cd Test3; run.pl";

print "Test4 directory tests\n";
system "cd Test4; run.pl";

print "Test5 directory tests\n";
system "cd Test5; run.pl";
