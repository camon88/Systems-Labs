static int k = 4;
int foo()
{
   
}
