
int k = 5;
int main()
{
    foo();
}
