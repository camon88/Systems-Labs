#include "cachelab.h"

int main(int argc, char * argv[])
{

    // pass to printSummary the number of hits, misses and evictions
    printSummary(0, 0, 0);
    return 0;
}
