#include "cachelab.h"
#include <ctype.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <getopt.h>
#include <math.h>
#include <string.h>

//Jake Campos
//Jonathan Ward


typedef unsigned long tag;
int verbose = -1;



typedef struct {
    int numberOfSets;
    int setIndexBits;
    int numberOfLines; //associativity
    int numberBlockBits;
    int blockSize;
    tag** tags;
} cache;

void cacheSetup(cache* cache, int sValue, int EValue, int bValue);

void parse(char* tline, cache* cache);

//void cacheSimulation() //STILL NEED TO IMPLEMENT THIS

int main(int argc, char * argv[]) {

              


     
        char str[80];
        int hitCount = 0;
        int missCount = 0;
        int evictionCount = 0;
        int hflag = -1;
        int sValue = -1;
        int EValue = -1;
        int bValue = -1;
        char * tValue = malloc(80);
        int c;
       

        cache cache;
       
    while ((c = getopt(argc, argv, "hvs:E:b:t:")) != -1)
            switch (c) {
            case 'h':
                hflag = 1;
                break;
            case 'v':
                verbose = 1;
                break;
            case 's':
                sValue = atoi(optarg);
                break;
            case 'E':
                EValue = atoi(optarg);
                break;
            case 'b':
                bValue = atoi(optarg);
                break;
            case 't':
                tValue = optarg;
                break;
            default:
                abort();
            }
        cacheSetup(&cache, sValue, EValue, bValue);

        //For Testing Paramter Parsing.
        if(verbose == 1)
        {
         printf("hflag = %d\nvflag = %d\nsValue = %d\nEValue = %d\nbValue = %d\ntValue = %s\n",
         hflag, verbose, sValue, EValue, bValue, tValue);
        }
     

        FILE * fp = fopen(tValue, "r");


        if (fp == NULL) {
            perror("Cannot Open File.");
            return (-1);
        }
        else
         {
          while(fgets(str, 80, fp) != NULL) 
          {
            parse(str, &cache);
          }
        }
        printSummary(hitCount, missCount, evictionCount);
        fclose(fp);
        return (0);
    }   
    

void cacheSetup(cache* cache, int sValue, int EValue, int bValue)
{    
    cache->numberOfSets = pow(2,sValue);
    cache->setIndexBits = sValue;
    cache->numberOfLines = EValue;
    cache->blockSize = pow(2,bValue);
    cache->numberBlockBits = bValue;
    cache->tags = malloc(cache->numberOfSets * sizeof(tag));
    for(int i = 0; i < cache -> numberOfSets; i++)
    {
        cache->tags[i] = malloc(cache->numberOfLines * sizeof(tag));
        memset(cache->tags[i], -1, cache->numberOfLines * sizeof(tag));
    }
}

void parse(char* tline, cache* cache)
{
//int address;
//int data;    
int index;
char *ptr = strchr(tline, ',');
index = (int)(ptr - tline);

 if(tline[0] == 'I')
     {
        // puts(tline);
     } 
 else if(tline[1] == 'L')
    {
        if(verbose == 1)
        {
            puts(tline);
        }
    }
 else if(tline[1] == 'M')
 {
     if(verbose == 1)
     {
         puts(tline);
     }

 }
 else if(tline[1] == 'S')
 {
    if(verbose == 1)
    {
        puts(tline);
    }
 }
 else 
 {
     puts("Error");
 }
}

char load(char* loc)
{
    return 'h';
}

char store(char* loc)
{
    return 'h';
}


char mod(char* loc)
{
    return 'h';
}

unsigned long getBits(int high, int low, unsigned long source) {
    if (high > 63 || high < 0 || low < 0 || low > 63) {
        printf("Invalid.");
    }
    return (source << (63 - high)) >> (63 - high + low);
}
